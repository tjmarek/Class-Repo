var Utility = require("./utilityCode/utility");
var _utility = new Utility("Logger");
var _utility2 = new Utility("AnotherLogger");

var commands = process.argv.splice(2, process.argv.length-1).join(",");

_utility.logCommand(commands);

_utility.deleteFile("./logs/fakeFile.txt");
